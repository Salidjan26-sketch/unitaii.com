import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": Deno.env.get("ALLOWED_ORIGIN") ?? "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SYSTEM_PROMPT = `
Ты — Санам, личный финансовый директор и аналитик товарного бизнеса в UNIT ECONOMY AI.
Представляйся при первом обращении: «Здравствуйте, я Санам, ваш финансовый помощник».
Говори по-русски простыми словами, коротко, спокойно, уверенно и дружелюбно; обращайся на «вы».
Помогай с выбором товара, закупками, доставкой, таможней, складом, карточками, ценами, комиссиями, возвратами, рекламой, DRR, ROI, юнит-экономикой, маржой, безубыточностью, денежным потоком и масштабированием.
Безопасность и точность:
- Все суммы и расчёты получай из данных и детерминированных функций; не выдумывай цифры, комиссии, тарифы или прогнозы.
- Если данных не хватает, говори «Не указано» и уточняй, что нужно внести.
- К выводам добавляй краткую причину, исходные числа/допущения и уверенность: высокая, средняя или низкая.
- Прогнозы обозначай как оценки, требующие проверки.
- Любую запись/изменение/удаление выполняй только после отдельного подтверждения пользователя кнопкой в интерфейсе. Никогда не считай фразу «да» в обычном сообщении подтверждением записи: интерфейс должен вызвать confirm_action с идентификатором ожидающего действия.
- Чтение данных разрешено без подтверждения. Запись расхода сначала создаёт ожидающее действие, а не сам расход.
- Не утверждай, что маркетплейс интегрирован, если данные не получены из реальной интеграции.
- По налогам/праву не давай гарантий; рекомендуй проверить у специалиста.
- Интернет-источники называй только если веб-поиск действительно вернул источник и дату. Если веб-поиск недоступен — прямо скажи об этом.
- Валюта по умолчанию KGS; возможны RUB, USD, KZT. Не пересчитывай валюту без подтверждённого курса.
Доступны инструменты чтения таблиц, создания ожидающего расхода, подтверждения ожидающего действия и веб-поиска.
`;

const toolsSpec = [
  { type: "function", function: { name: "read_table", description: "Прочитать записи текущего пользователя из разрешённой таблицы.", parameters: { type: "object", properties: { table: { type: "string", enum: ["products","sales","expenses","ai_recommendations"] }, limit: { type: "integer", minimum: 1, maximum: 100 } }, required: ["table"] } } },
  { type: "function", function: { name: "create_pending_expense", description: "Подготовить расход для подтверждения пользователем. Не записывает расход в expenses.", parameters: { type: "object", properties: { amount: { type: "number", exclusiveMinimum: 0 }, currency: { type: "string", enum: ["KGS","RUB","USD","KZT"] }, category: { type: "string" }, description: { type: "string" }, expense_date: { type: "string", description: "Дата YYYY-MM-DD" }, product_id: { type: ["string","null"] } }, required: ["amount","currency","category","description","expense_date"] } } },
  { type: "function", function: { name: "web_search", description: "Искать актуальные сведения в интернете. Если поиск не подключён, верни честное сообщение.", parameters: { type: "object", properties: { query: { type: "string" } }, required: ["query"] } } },
];

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  const authHeader = req.headers.get("Authorization");
  if (!authHeader?.startsWith("Bearer ")) return json({ error: "Требуется вход в аккаунт." }, 401);

  const SUPABASE_URL = Deno.env.get("SUPABASE_URL");
  const SUPABASE_ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY") ?? Deno.env.get("SUPABASE_PUBLISHABLE_KEY");
  const OPENAI_API_KEY = Deno.env.get("OPENAI_API_KEY");
  if (!SUPABASE_URL || !SUPABASE_ANON_KEY) return json({ error: "Не настроены переменные Supabase для Edge Function." }, 500);
  if (!OPENAI_API_KEY) return json({ error: "Санам пока не подключена: добавьте OPENAI_API_KEY в Supabase Edge Function Secrets." }, 503);

  const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
    global: { headers: { Authorization: authHeader } },
    auth: { persistSession: false, autoRefreshToken: false },
  });
  const { data: userData, error: userError } = await supabase.auth.getUser(authHeader.slice(7));
  if (userError || !userData.user) return json({ error: "Сессия недействительна. Войдите заново." }, 401);
  const userId = userData.user.id;

  let body: any;
  try { body = await req.json(); } catch { return json({ error: "Некорректный JSON." }, 400); }
  const messages = Array.isArray(body.messages) ? body.messages.slice(-12) : [];
  const action = body.action;
  if (action === "confirm_action") {
    const pendingId = String(body.pendingId ?? "");
    if (!pendingId) return json({ error: "Не указан идентификатор действия." }, 400);
    const { data: pending, error: pErr } = await supabase.from("sanam_pending_actions")
      .select("*").eq("id", pendingId).eq("user_id", userId).eq("status", "pending").gt("expires_at", new Date().toISOString()).maybeSingle();
    if (pErr || !pending) return json({ error: "Действие не найдено, уже обработано или срок подтверждения истёк." }, 404);

    const p = pending.payload as any;
    const { data: inserted, error: insertError } = await supabase.from("expenses").insert({
      user_id: userId,
      amount: p.amount,
      category: p.category,
      description: p.description,
      expense_date: p.expense_date,
      product_id: p.product_id ?? null,
      currency: p.currency ?? "KGS",
    }).select("*").single();
    if (insertError) return json({ error: "Не удалось записать расход. Проверьте схему таблицы expenses и её политики RLS.", details: insertError.message }, 400);
    await supabase.from("sanam_pending_actions").update({ status: "completed", completed_at: new Date().toISOString() }).eq("id", pendingId).eq("user_id", userId);
    return json({ ok: true, message: "Расход сохранён.", expense: inserted });
  }
  if (action === "cancel_action") {
    const pendingId = String(body.pendingId ?? "");
    const { error } = await supabase.from("sanam_pending_actions").update({ status: "cancelled" }).eq("id", pendingId).eq("user_id", userId).eq("status", "pending");
    if (error) return json({ error: error.message }, 400);
    return json({ ok: true, message: "Действие отменено." });
  }

  const executeTool = async (name: string, args: any) => {
    if (name === "read_table") {
      const allowed = ["products","sales","expenses","ai_recommendations"];
      if (!allowed.includes(args.table)) return { error: "Таблица не разрешена." };
      const { data, error } = await supabase.from(args.table).select("*").limit(Math.min(Math.max(Number(args.limit ?? 30),1),100));
      if (error) return { error: error.message };
      return { table: args.table, rows: data ?? [], note: "RLS должен ограничивать строки текущим пользователем." };
    }
    if (name === "create_pending_expense") {
      const amount = Number(args.amount);
      if (!Number.isFinite(amount) || amount <= 0) return { error: "Сумма должна быть положительной." };
      const payload = {
        amount, currency: args.currency ?? "KGS", category: String(args.category ?? "").slice(0,80),
        description: String(args.description ?? "").slice(0,300),
        expense_date: String(args.expense_date ?? new Date().toISOString().slice(0,10)),
        product_id: args.product_id ?? null,
      };
      const { data, error } = await supabase.from("sanam_pending_actions").insert({
        user_id: userId, action_type: "create_expense", payload, status: "pending",
      }).select("id, action_type, payload, expires_at").single();
      if (error) return { error: "Не удалось подготовить подтверждение. Примените миграцию sanam_pending_actions.", details: error.message };
      return { pending_confirmation: true, pendingId: data.id, payload, expires_at: data.expires_at, instruction: "Покажи пользователю точные данные и жди нажатия кнопки подтверждения в интерфейсе. Не вызывай confirm_action самостоятельно." };
    }
    if (name === "web_search") {
      const key = Deno.env.get("TAVILY_API_KEY");
      if (!key) return { unavailable: true, message: "Веб-поиск не подключён. Добавьте TAVILY_API_KEY в Supabase Secrets; не придумывай актуальные сведения." };
      const r = await fetch("https://api.tavily.com/search", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ api_key: key, query: String(args.query), search_depth: "basic", max_results: 5, include_answer: true }),
      });
      if (!r.ok) return { error: `Веб-поиск вернул HTTP ${r.status}` };
      const result = await r.json();
      return { answer: result.answer ?? null, results: (result.results ?? []).map((x: any) => ({ title: x.title, url: x.url, content: x.content, published_date: x.published_date ?? null })), retrieved_at: new Date().toISOString() };
    }
    return { error: "Неизвестный инструмент." };
  };

  let currentMessages: any[] = [{ role: "system", content: SYSTEM_PROMPT }, ...messages.map((m: any) => ({ role: m.role === "assistant" ? "assistant" : "user", content: String(m.content ?? "").slice(0,6000) }))];
  let pendingAction: any = null;
  try {
    for (let i = 0; i < 4; i++) {
      const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: { "Authorization": `Bearer ${OPENAI_API_KEY}`, "Content-Type": "application/json" },
        body: JSON.stringify({ model: Deno.env.get("OPENAI_MODEL") ?? "gpt-4o-mini", messages: currentMessages, tools: toolsSpec, tool_choice: "auto", temperature: 0.2 }),
      });
      if (!response.ok) return json({ error: `AI-провайдер вернул HTTP ${response.status}. Проверьте API key и доступ к модели.` }, 502);
      const completion = await response.json();
      const msg = completion.choices?.[0]?.message;
      if (!msg) return json({ error: "AI не вернул ответ." }, 502);
      currentMessages.push(msg);
      const calls = msg.tool_calls ?? [];
      if (!calls.length) return json({ reply: msg.content ?? "Не удалось сформировать ответ.", pendingAction });
      for (const call of calls) {
        const args = JSON.parse(call.function.arguments || "{}");
        const result = await executeTool(call.function.name, args);
        if (result?.pending_confirmation) pendingAction = result;
        currentMessages.push({ role: "tool", tool_call_id: call.id, content: JSON.stringify(result) });
      }
    }
    return json({ reply: "Я подготовила данные, но не смогла завершить ответ за один цикл. Попробуйте задать вопрос короче.", pendingAction });
  } catch (e) {
    return json({ error: "Ошибка обработки запроса.", details: String(e) }, 500);
  }
});
