import React, { useEffect, useRef, useState } from "react";
import type { SupabaseClient } from "@supabase/supabase-js";
import "../lib/sanam.css";

type ChatMessage = { role: "user" | "assistant"; content: string };
type Props = { supabase: SupabaseClient; functionName?: string };

export default function SanamAssistant({ supabase, functionName = "sanam" }: Props) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: "assistant", content: "Здравствуйте, я Санам, ваш финансовый помощник. Чем могу помочь?" },
  ]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [speak, setSpeak] = useState(true);
  const [voiceStatus, setVoiceStatus] = useState("");
  const [pending, setPending] = useState<any>(null);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, pending]);

  const speakText = (text: string) => {
    if (!speak || !("speechSynthesis" in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "ru-RU";
    const voices = window.speechSynthesis.getVoices();
    const russian = voices.filter(v => v.lang.toLowerCase().startsWith("ru"));
    const female = russian.find(v => /female|жен|milena|alena|katya|irina/i.test(v.name));
    utterance.voice = female ?? russian[0] ?? null;
    if (!female) setVoiceStatus(russian.length ? "Используется доступный русский голос; выбор женского голоса зависит от iPhone." : "Русский голос не найден на устройстве.");
    window.speechSynthesis.speak(utterance);
  };

  const send = async (text = input) => {
    const content = text.trim();
    if (!content || busy) return;
    const next = [...messages, { role: "user" as const, content }];
    setMessages(next); setInput(""); setBusy(true); setPending(null); setVoiceStatus("");
    try {
      const { data: sessionData, error: sessionError } = await supabase.auth.getSession();
      const token = sessionData.session?.access_token;
      if (sessionError || !token) throw new Error("Сначала войдите в свой аккаунт.");
      const { data, error } = await supabase.functions.invoke(functionName, {
        body: { messages: next.slice(-12) },
        headers: { Authorization: `Bearer ${token}` },
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      const reply = String(data?.reply ?? "Ответ не получен.");
      setMessages(prev => [...prev, { role: "assistant", content: reply }]);
      if (data.pendingAction) setPending(data.pendingAction);
      speakText(reply);
    } catch (e: any) {
      const message = e?.message ?? "Не удалось связаться с Санам.";
      setMessages(prev => [...prev, { role: "assistant", content: `Не получилось выполнить запрос: ${message}` }]);
    } finally { setBusy(false); }
  };

  const confirm = async (action: "confirm_action" | "cancel_action") => {
    if (!pending?.pendingId) return;
    setBusy(true);
    try {
      const { data: sessionData } = await supabase.auth.getSession();
      const token = sessionData.session?.access_token;
      if (!token) throw new Error("Сессия завершена. Войдите снова.");
      const { data, error } = await supabase.functions.invoke(functionName, {
        body: { action, pendingId: pending.pendingId },
        headers: { Authorization: `Bearer ${token}` },
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      const msg = action === "confirm_action"
        ? `Готово. ${data.message} Сумма: ${pending.payload.amount} ${pending.payload.currency}. Проверьте обновлённые показатели в разделе расходов.`
        : "Действие отменено. Расход не записан.";
      setMessages(prev => [...prev, { role: "assistant", content: msg }]);
      setPending(null); speakText(msg);
    } catch (e: any) {
      setMessages(prev => [...prev, { role: "assistant", content: `Не удалось обработать подтверждение: ${e?.message ?? "ошибка"}` }]);
    } finally { setBusy(false); }
  };

  const startVoice = () => {
    const w = window as any;
    const Recognition = w.SpeechRecognition || w.webkitSpeechRecognition;
    if (!Recognition) { setVoiceStatus("Распознавание речи не поддерживается в этом браузере. Напишите команду в чате."); return; }
    const recognition = new Recognition();
    recognition.lang = "ru-RU"; recognition.interimResults = false; recognition.maxAlternatives = 1;
    setVoiceStatus("Слушаю…");
    recognition.onresult = (event: any) => { const text = event.results?.[0]?.[0]?.transcript ?? ""; setVoiceStatus(`Распознано: ${text}`); if (text) void send(text); };
    recognition.onerror = () => setVoiceStatus("Не удалось распознать речь. Проверьте разрешение на микрофон или напишите текст.");
    recognition.onend = () => setVoiceStatus(s => s === "Слушаю…" ? "Голосовой ввод завершён." : s);
    recognition.start();
  };

  return <section className="sanam-shell" aria-label="AI-помощник Санам">
    <header className="sanam-header">
      <div className="sanam-avatar">С</div>
      <div><strong>Санам</strong><small>AI · Финансовый помощник</small></div>
      <label className="sanam-speak"><input type="checkbox" checked={speak} onChange={e => setSpeak(e.target.checked)} /> Озвучивать</label>
    </header>
    <div className="sanam-messages">
      {messages.map((m, i) => <div key={i} className={`sanam-message ${m.role}`}>{m.content}</div>)}
      {busy && <div className="sanam-message assistant">Санам анализирует…</div>}
      {pending && <div className="sanam-confirm">
        <strong>Подтвердите добавление расхода</strong>
        <p>Сумма: <b>{pending.payload.amount} {pending.payload.currency}</b></p>
        <p>Категория: {pending.payload.category}</p>
        <p>Описание: {pending.payload.description}</p>
        <p>Дата: {pending.payload.expense_date}</p>
        <div className="sanam-actions">
          <button disabled={busy} onClick={() => confirm("confirm_action")}>Подтвердить запись</button>
          <button className="secondary" disabled={busy} onClick={() => confirm("cancel_action")}>Отмена</button>
        </div>
      </div>}
      <div ref={endRef} />
    </div>
    {voiceStatus && <p className="sanam-status" role="status">{voiceStatus}</p>}
    <form className="sanam-input-row" onSubmit={e => { e.preventDefault(); void send(); }}>
      <button type="button" className="sanam-mic" aria-label="Голосовой ввод" onClick={startVoice} disabled={busy}>🎙</button>
      <input value={input} onChange={e => setInput(e.target.value)} placeholder="Спросите о прибыли или расходах…" aria-label="Сообщение Санам" />
      <button type="submit" disabled={busy || !input.trim()}>Отправить</button>
    </form>
    {voiceStatus && /женский голос|голос не найден/i.test(voiceStatus) && <small className="sanam-status">{voiceStatus}</small>}
  </section>;
}
