-- UNIT ECONOMY AI — schema for Supabase
-- Run in Supabase SQL Editor. Review existing table definitions first.
-- This creates missing tables and policies; it does not expose service_role keys.

create extension if not exists pgcrypto;

create table if not exists public.products (
  id text primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  sku text default '',
  category text default '',
  marketplace text default '',
  purchase_price numeric not null default 0,
  sale_price numeric not null default 0,
  stock numeric not null default 0,
  commission_percent numeric not null default 0,
  logistics_cost numeric not null default 0,
  ads_cost numeric not null default 0,
  packaging_cost numeric not null default 0,
  tax_percent numeric not null default 0,
  returns_percent numeric not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.sales (
  id text primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  product_id text,
  product_name text not null default '',
  quantity numeric not null default 1,
  sale_price numeric not null default 0,
  total_revenue numeric not null default 0,
  total_cost numeric not null default 0,
  profit numeric not null default 0,
  sale_date date not null default current_date,
  note text default '',
  created_at timestamptz not null default now()
);

create table if not exists public.expenses (
  id text primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  amount numeric not null default 0,
  category text not null default 'Прочее',
  expense_date date not null default current_date,
  note text default '',
  created_at timestamptz not null default now()
);

create table if not exists public.ai_recommendations (
  id text primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null default '',
  description text not null default '',
  priority text not null default 'normal',
  created_at timestamptz not null default now()
);

alter table public.products enable row level security;
alter table public.sales enable row level security;
alter table public.expenses enable row level security;
alter table public.ai_recommendations enable row level security;

drop policy if exists "Users manage own products" on public.products;
create policy "Users manage own products" on public.products for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "Users manage own sales" on public.sales;
create policy "Users manage own sales" on public.sales for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "Users manage own expenses" on public.expenses;
create policy "Users manage own expenses" on public.expenses for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "Users manage own recommendations" on public.ai_recommendations;
create policy "Users manage own recommendations" on public.ai_recommendations for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

create index if not exists products_user_id_idx on public.products(user_id);
create index if not exists sales_user_date_idx on public.sales(user_id, sale_date);
create index if not exists expenses_user_date_idx on public.expenses(user_id, expense_date);
