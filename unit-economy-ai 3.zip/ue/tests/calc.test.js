import test from 'node:test'; import assert from 'node:assert/strict'
import { calc, validate, volumeL } from '../src/calc.js'
const p = { sku:'A', name:'A', cost:300, price:900, length:20, width:15, height:10, pack:15, delivery:20, commission:20, logistics:80, extra:10, drr:8, returns:5, sales:10 }
test('volume', () => assert.equal(volumeL(p), 3))
test('profit', () => { const r = calc(p); assert.ok(Math.abs(r.profit - (900-300-15-20-80-10-4.5-180-72)) < 1e-9) })
test('breakeven gives zero profit', () => { const r = calc(p); assert.ok(Math.abs(calc({ ...p, price: r.minPrice }).profit) < 1e-6) })
test('target margin reached', () => { const r = calc(p, 15); const q = calc({ ...p, price: r.target }); assert.ok(Math.abs(q.margin - 15) < 1e-6) })
test('validation', () => { assert.ok(validate({ ...p, commission: 95, drr: 10 }).length > 0) })
