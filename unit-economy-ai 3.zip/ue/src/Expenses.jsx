import { useState } from 'react'
import { supabase } from './supabase.js'
import { rub } from './calc.js'
export const CATS = ['Закупочная стоимость','Международная доставка','Доставка до склада','Таможня и налоги','Комиссия маркетплейса','Логистика до покупателя и обратно','Упаковка и маркировка','Хранение','Реклама','Эквайринг','Возвраты, отмены и брак','Зарплата, аренда, операционные','Другое']
const blank = () => ({ category: CATS[0], amount: '', qty: 1, date: new Date().toISOString().slice(0, 10), product_id: '', comment: '' })
export default function Expenses({ items, expenses, reload, setErrs }) {
  const [f, setF] = useState(blank()); const [q, setQ] = useState(''); const [cat, setCat] = useState('')
  async function add(e) {
    e.preventDefault()
    const amount = Number(String(f.amount).replace(',', '.')); const qty = Number(f.qty)
    if (!(amount > 0) || !(qty > 0)) return setErrs(['Сумма и количество должны быть больше нуля'])
    const dup = expenses.some(x => x.category === f.category && Number(x.amount) === amount && x.date === f.date && (x.product_id || '') === f.product_id && (x.comment || '') === f.comment)
    if (dup && !confirm('Такой расход уже есть. Добавить ещё раз?')) return
    const { error } = await supabase.from('expenses').insert({ ...f, amount, qty, product_id: f.product_id || null })
    if (error) return setErrs([error.message])
    setErrs([]); setF(blank()); reload()
  }
  async function del(id) {
    if (!confirm('Удалить расход?')) return
    const { error } = await supabase.from('expenses').delete().eq('id', id)
    if (error) setErrs([error.message]); else reload()
  }
  const name = id => items.find(p => p.id === id)?.name || 'Общий расход'
  const list = expenses.filter(x => (!cat || x.category === cat) && (x.comment + ' ' + name(x.product_id)).toLowerCase().includes(q.toLowerCase()))
  const set = k => e => setF({ ...f, [k]: e.target.value })
  return <>
    <form className="form" onSubmit={add}>
      <label>Категория<select value={f.category} onChange={set('category')}>{CATS.map(c => <option key={c}>{c}</option>)}</select></label>
      <label>Сумма<input type="number" step="any" min="0" value={f.amount} onChange={set('amount')} required /></label>
      <label>Количество<input type="number" min="1" value={f.qty} onChange={set('qty')} /></label>
      <label>Дата<input type="date" value={f.date} onChange={set('date')} /></label>
      <label>Товар<select value={f.product_id} onChange={set('product_id')}><option value="">Общий расход магазина</option>{items.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select></label>
      <label>Комментарий<input value={f.comment} onChange={set('comment')} /></label>
      <button className="btn gold">Добавить расход</button>
    </form>
    <div className="bar" style={{ marginTop: 16 }}><input placeholder="Поиск по комментарию или товару" value={q} onChange={e => setQ(e.target.value)} />
      <select value={cat} onChange={e => setCat(e.target.value)}><option value="">Все категории</option>{CATS.map(c => <option key={c}>{c}</option>)}</select></div>
    <div className="tw"><table><thead><tr><th>Дата</th><th>Категория</th><th>Товар</th><th>Сумма</th><th>Комментарий</th><th></th></tr></thead>
      <tbody>{list.map(x => <tr key={x.id}><td>{x.date}</td><td>{x.category}</td><td>{name(x.product_id)}</td><td>{rub(x.amount * x.qty)}</td><td>{x.comment}</td>
        <td><button className="btn ghost" onClick={() => del(x.id)}>Удалить</button></td></tr>)}</tbody></table></div>
    <p className="note">Общие расходы вычитаются из прибыли на дашборде. Распределение по товарам — следующий этап.</p>
  </>
}
