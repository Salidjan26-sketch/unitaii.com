create table if not exists products (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  sku text not null, name text not null,
  cost numeric default 0, price numeric default 0,
  length numeric default 0, width numeric default 0, height numeric default 0, weight numeric default 0,
  pack numeric default 0, delivery numeric default 0,
  commission numeric default 0, logistics numeric default 0, extra numeric default 0,
  drr numeric default 0, returns numeric default 0, sales integer default 0,
  created_at timestamptz default now(), updated_at timestamptz default now()
);
alter table products enable row level security;
create policy "own rows select" on products for select using (auth.uid() = user_id);
create policy "own rows insert" on products for insert with check (auth.uid() = user_id);
create policy "own rows update" on products for update using (auth.uid() = user_id);
create policy "own rows delete" on products for delete using (auth.uid() = user_id);
