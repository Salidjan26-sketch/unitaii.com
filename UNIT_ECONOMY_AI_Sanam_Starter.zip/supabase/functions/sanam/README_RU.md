# Санам — Edge Function

Secrets в Supabase:
- `OPENAI_API_KEY` (обязательно)
- `OPENAI_MODEL` (необязательно, по умолчанию `gpt-4o-mini`)
- `TAVILY_API_KEY` (необязательно; включает веб-поиск)
- `ALLOWED_ORIGIN` (рекомендуется ограничить доменом опубликованного приложения)
- `SUPABASE_URL` и ключ клиента обычно доступны Supabase Edge Functions автоматически; если нет — задайте URL и anon/publishable key как secrets.

Функция использует Authorization JWT текущего пользователя и Supabase-клиент с пользовательским токеном. Поэтому RLS обязателен. Проверьте политики на `products`, `sales`, `expenses`, `ai_recommendations` и `sanam_pending_actions`.

Поля записи расхода в текущем шаблоне: `user_id`, `amount`, `category`, `description`, `expense_date`, `product_id`, `currency`. Сверьте их с вашей таблицей `expenses` до первого теста.

В текущей версии чтение разрешено для `products`, `sales`, `expenses`, `ai_recommendations`. Инструмент веб-поиска возвращает URL и дату получения; если `TAVILY_API_KEY` отсутствует, он честно возвращает состояние «поиск не подключён».
