-- Таблица подтверждений защищена RLS. Пользователь может видеть только собственные действия.
create table if not exists public.sanam_pending_actions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  action_type text not null check (action_type in ('create_expense')),
  payload jsonb not null,
  status text not null default 'pending' check (status in ('pending','confirmed','cancelled','completed','failed')),
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default (now() + interval '15 minutes'),
  completed_at timestamptz
);

alter table public.sanam_pending_actions enable row level security;

create policy "Users read own Sanam actions"
on public.sanam_pending_actions for select
using (auth.uid() = user_id);

create policy "Users create own Sanam actions"
on public.sanam_pending_actions for insert
with check (auth.uid() = user_id);

create policy "Users update own Sanam actions"
on public.sanam_pending_actions for update
using (auth.uid() = user_id)
with check (auth.uid() = user_id);
