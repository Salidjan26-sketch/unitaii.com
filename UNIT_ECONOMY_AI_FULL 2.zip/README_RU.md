# UNIT ECONOMY AI — Full starter platform

## Included
- Responsive Russian-language web app, mobile-first for iPhone
- Product catalogue and unit economics calculator
- Sales recording and inventory reduction
- Expense tracking
- Dashboard, product ranking, margin and profitability analytics
- Rule-based recommendations from entered data
- JSON backup and CSV product import
- Optional Supabase email auth and cloud persistence
- SQL schema and Row Level Security policies

## Deploy from iPhone with Netlify
1. Extract this ZIP if needed; Netlify Drop should receive the contents as a folder/ZIP according to the current Netlify UI.
2. Publish `index.html` as a static site. The app uses a Supabase JS CDN and does not require a build command.
3. Open the generated `*.netlify.app` URL in Safari.

## Supabase
1. Open Supabase → SQL Editor and inspect existing tables before applying `supabase/setup.sql`.
2. If your existing tables were created using a different schema, do not blindly run the SQL: reconcile column names first.
3. In Supabase Project Settings / API, copy the Project URL and the Publishable key (or legacy anon key).
4. In the app open Settings, paste both values and enable cloud sync; then sign in with email.
5. Never paste a `service_role` or secret key into the browser.

## Important scope notes
- The app works in local mode without Supabase; local data stays in that browser/device until exported.
- Cloud sync requires Supabase tables matching the supplied schema, email auth, and RLS policies.
- The AI assistant in this starter uses transparent local rules, not a hosted generative AI model. To add an actual LLM, create a server-side Supabase Edge Function and store its provider API key as a server secret.
- Marketplace commissions are entered manually. Live Ozon/Wildberries tariff APIs are not connected in this starter.
- Forecasts and recommendations are indicative; verify fees, taxes, returns and accounting before business decisions.
- Current version uses standard table columns; it does not automatically migrate an existing custom schema.
