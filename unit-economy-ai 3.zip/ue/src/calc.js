export const FIELDS = [
 ['sku','SKU','text'],['name','Название','text'],['cost','Закупка (валюта)'],['price','Цена продажи (валюта)'],
 ['length','Длина, см'],['width','Ширина, см'],['height','Высота, см'],['weight','Вес, кг'],
 ['pack','Упаковка (валюта)'],['delivery','Доставка до склада (валюта)'],['commission','Комиссия, %'],
 ['logistics','Логистика (валюта)'],['extra','Доп. расходы (валюта)'],['drr','Реклама (ДРР), %'],
 ['returns','Возвраты, %'],['sales','Продаж, шт']]
export const EMPTY = Object.fromEntries(FIELDS.map(([k,,t]) => [k, t==='text' ? '' : 0]))
const n = v => { const x = Number(String(v).replace(',','.')); return Number.isFinite(x) ? x : 0 }
export const volumeL = p => n(p.length)*n(p.width)*n(p.height)/1000
export function validate(p) {
  const e = []
  if (!String(p.sku||'').trim()) e.push('Укажите SKU')
  if (!String(p.name||'').trim()) e.push('Укажите название')
  FIELDS.forEach(([k,l,t]) => { if (t!=='text' && n(p[k])<0) e.push(`${l}: значение не может быть отрицательным`) })
  if (n(p.commission)+n(p.drr)>=100) e.push('Комиссия + ДРР должны быть меньше 100%')
  if (n(p.returns)>100) e.push('Возвраты не могут быть больше 100%')
  return e
}
// Допущение: потери от возврата = доля возвратов × (логистика + доп. расходы); товар возвращается в продажу.
export function calc(p, targetMargin = 15) {
  const price=n(p.price), m=n(p.commission), d=n(p.drr), r=n(p.returns)
  const fixed = n(p.cost)+n(p.pack)+n(p.delivery)+n(p.logistics)+n(p.extra)
  const retLoss = r/100*(n(p.logistics)+n(p.extra))
  const commission = price*m/100, ads = price*d/100
  const full = fixed + retLoss
  const profit = price - full - commission - ads
  const k = (x) => { const q = 1 - x/100; return q>0 ? full/q : null }
  return { volume: volumeL(p), full, commission, ads, retLoss, profit,
    margin: price>0 ? profit/price*100 : 0, total: profit*n(p.sales),
    revenue: price*n(p.sales), breakEven: k(m+d), minPrice: k(m+d), target: k(m+d+targetMargin) }
}
let CUR = 'KGS'
export const CURRENCIES = ['KGS','RUB','USD','KZT']
export const setCurrency = c => { CUR = c }
export const rub = v => v==null ? 'Не указано' : new Intl.NumberFormat('ru-RU',{style:'currency',currency:CUR,maximumFractionDigits:2}).format(v)
export const pct = v => new Intl.NumberFormat('ru-RU',{maximumFractionDigits:1}).format(v)+'%'
